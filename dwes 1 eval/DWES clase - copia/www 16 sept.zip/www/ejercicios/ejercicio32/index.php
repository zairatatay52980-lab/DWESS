<?php

$numerosAleatorios = random_int(1,999)[20];


?>