<?php

//conexion a la base de datos  

$dbname = "tema4";
$host = "localhost";
$user = "root";
$pass = "";

function connect($host, $dbname, $user, $pass){
    try {

        $db= new PDO("mysql:host=$host;dbname=$dbname", $user , $pass );

        return $db;
    }
    catch(PDOException $e) {
        echo $e->getMessage();
        return null;
    }
}

$db = connect($host, $dbname , $user , $pass);


  





?> 