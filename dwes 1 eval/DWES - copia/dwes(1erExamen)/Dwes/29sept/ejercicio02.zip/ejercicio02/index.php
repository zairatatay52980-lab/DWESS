<?php 
function conectar(): PDO {
    return new PDO("mysql:host=localhost;
                    dbname=tema4ejerc02;
                    charset=utf8", 
                    "root", 
                    "");
}


$db = conectar();


$accion = $_GET['accion'] ?? '';

switch($accion){
    case 'mostrarEmpleado':
        if(!empty($_GET))


    break;
    case 'insertar':


    break;
    case 'eliminar':

    break;
    case 'mostrarDetalle':


    break;
    case 'vaciar':
        vaciarLista($db);
        header("Location: index.php");
    exit;


}


?>