<?php

require "db_functions.php";

function bodegaFromPost(): array{
    return array(
        "nombre" =>$_POST["nombre"],
        "direccion" =>$_POST["direccion"],
        "email" =>$_POST["email"],
        "telefono" =>$_POST["telefono"],
        "contacto" =>$_POST["contacto"],
        "nombre" =>$_POST["nombre"],



    );


}















require "views/index.view.php";

?>