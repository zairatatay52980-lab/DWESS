<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inicio</title>
</head>
<body>
    <header>
            <h1>Ejercicio Bodegas</h1>
    </header>

    <main class="contenedor">
        <div class="listado-bodegas">
            <h3>Lista de bodegas</h3>

            <table border=1>
                <tr>
                    <th>Nombre</th>
                    <th>Localizacion</th>
                    <th>Telefono</th>
                    <th>Email</th>
                    <th>Acciones</th>
                </tr>
                <tr>
                    <td>/*nombre*/</td>
                    <td>/*Localizacion*/</td>
                    <td>/*Telefono*/</td>
                    <td>/*Email*/</td>
                    <td><a href="index.php?accion=entrar">Entrar</a>||
                        <a href="index.php?accion=eliminar">Borrar</a>
                    </td>

                </tr>

            </table>

        </div>


















    </main>
</body>
</html>