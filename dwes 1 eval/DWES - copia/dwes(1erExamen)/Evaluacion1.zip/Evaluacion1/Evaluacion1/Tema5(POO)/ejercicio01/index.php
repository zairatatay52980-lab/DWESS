<?php

class Publicacion{
    
}
