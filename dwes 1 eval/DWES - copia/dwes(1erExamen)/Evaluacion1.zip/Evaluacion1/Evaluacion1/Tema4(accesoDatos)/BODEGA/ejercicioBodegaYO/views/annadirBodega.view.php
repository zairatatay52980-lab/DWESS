<?php require "layout/head.php";?>
    
 <form action="index.php?accion=bodegaInsertar" method="post">
    
    <?php  
    $bodega=null;
    $soloLectura = false;

    require "partials/bodegaCampos.php";
    ?>
    <p>
            <input type='submit' value='Añadir'>
        </p>
  
    </form>
    <p>
    <a href="index.php">Volver</a>
    </p>

<?php require "layout/footer.php";?>