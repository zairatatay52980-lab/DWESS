<?php 
require 'layout/head.php'; 
?>

<div>
    <!-- Datos de la bodega -->
        <div>
            <h4>Datos bodega</h4>
            <div>
                <a href="index.php?accion=bodegaActualizar&id=<?= $bodega->id ?>">Editar</a>
                <a href="index.php">Volver</a>
                <a href="index.php?accion=bodega_eliminar&id=<?= $bodega->id ?>"> Eliminar</a>
            </div>
        </div>

        <form action="index.php?accion=bodega_actualizar" method="post">
            <input type="hidden" name="id" value="<?= $id ?>">
            <?php require 'partials/bodegaCampos.php' ?>
        </form>
    </div>

    <!-- Vinos de la bodega -->
    <div>
        <div>
            <h4>Vinos disponibles</h4>
            <a href="index.php?accion=vino_nuevo&bodega_id=<?= $id ?>">Añadir vino</a>
        </div>

        <table>
            <thead>
                <tr>
                    <th>Nombre</th>
                    <th>Tipo</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($vinos as $v) : ?>
                    <tr>
                        <td><?= htmlspecialchars($v->nombre) ?></td>
                        <td><?= htmlspecialchars($v->tipo) ?></td>
                        <td>
                            <a href="index.php?accion=vino_detalle&id=<?= $v->id ?>">Ver</a>
                            <a href="index.php?accion=vino_eliminar&id=<?= $v->id ?>">Borrar</a>
                        </td>
                    </tr>
                <?php endforeach; ?>

                <?php if (empty($vinos)) : ?>
                    <tr><td colspan="3">Esta bodega todavía no tiene vinos</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require 'layout/footer.php' ?>
