<?php require('layout/head.php')?>

            <a href="index.php?accion=bodegaNueva"> Añadir bodega</a>
            <table border=1>
                <thead>
                <tr>
                    <th>Nombre</th><th>Localizacion</th><th>Telefono</th><th>Email</th><th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <!-- foreach recargar contenido-->
                 <?php foreach($bodegas as $bodega): ?>
                <tr>
                    <td><?= htmlspecialchars($bodega->nombre)?></td>
                    <td><?=htmlspecialchars($bodega->direccion)?></td>
                    <td><?=htmlspecialchars($bodega->telefono ?? '')?></td>
                    <td><?= htmlspecialchars($bodega->email ?? '')?></td>
                    <td><a href="views/bodegaDetalle.php?accion=bodegaDetalle&id=<?=$bodega->id ?>">Entrar</a>||
                        <a href="index.php?accion=bodegaEliminar&id=<?=$bodega->id?>">Borrar</a>
                    </td>
            
                </tr>
                <?php endforeach;?>
                </tbody>
            </table>

        </div>
<?php require('layout/footer.php')?>