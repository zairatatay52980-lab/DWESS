<?php 
    
    $restaurante=$bodega ? $bodega->restaurante : 0;
    $hotel = $bodega ? $bodega->hotel : 0;
    ?>

        <fieldset>
        <legend>Datos bodega</legend>
        <div class="form-group">
            <label for="nombre">Nombre</label>
            <input type="text" id="nombre" name="nombre" class="form-control" placeholder="Nombre" required
                value="<?= $bodega->nombre ?? '' ?>">
        </div>
        <div class="form-group">
            <label for="direccion">Dirección</label>
            <input type="text" id="direccion" name="direccion" class="form-control" placeholder="Dirección" required
                value="<?= $bodega->direccion ?? '' ?>">
        </div>
        <div class="form-group">
            <label for="email">Email</label>
            <input type="email" id="email" name="email" class="form-control" placeholder="Email"
                value="<?= $bodega->email ?? '' ?>">
        </div>
        <div class="form-group">
            <label for="telefono">Teléfono</label>
            <input type="tel" id="telefono" name="telefono" class="form-control" placeholder="Teléfono"
                value="<?= $bodega->telefono ?? '' ?>">
        </div>
        <div class="form-group">
            <label for="contacto">Persona de contacto</label>
            <input type="text" id="contacto" name="contacto" class="form-control" placeholder="Persona de contacto"
                value="<?= $bodega->contacto ?? '' ?>">
        </div>
        <div class="form-group">
            <label for="fundacion">Año de fundación</label>
            <input type="number" id="fundacion" name="fundacion" class="form-control" placeholder="Año de fundación" min="1000" max="2100"
                value="<?= $bodega->fundacion ?? '' ?>">
        </div>
        <div class="form-group">
            <label for="descripcion">Descripción</label>
            <textarea id="descripcion" name="descripcion" class="form-control" rows="3"><?= $bodega->descripcion ?? '' ?></textarea>
        </div>
        <h5>Dispone de restaurante</h5>
        <div>
            <input type="radio" name="restaurante" id="restaurante-si" value="1" <?=$restaurante ? "checked" : "" ?>>
            <label for="hotel-si">Si</label>
        </div>
        <div>
            <input type="radio" name="restaurante" id="restaurante-no" value="0"<?=!$restaurante ? "checked" : ""?>> 
            <label for="restaurante-no">No</label>
        </div>
        <h5>Dispone de hotel?</h5>
        <div>
            <input type="radio" name="hotel" id="hotel-si" value="1" <?=$hotel ? "checked" : "" ?>>
            <label for="hotel-si">Si</label>
        </div>
        <div>
            <input type="radio" name="hotel" id="hotel-no" value="0" <?=!$hotel ? "checked" : "" ?> >
            <label for="hotel-no">No</label>
        </div>
       
        
    </fieldset>