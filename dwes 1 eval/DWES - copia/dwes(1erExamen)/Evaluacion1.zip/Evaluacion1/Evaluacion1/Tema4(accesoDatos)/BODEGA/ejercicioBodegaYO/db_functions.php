<?php 

require_once "BBDD/database.php";

/**BODEGAS */

function getAllBodegas(): array{
    $db =  getDbConnection();
    $stmt = $db->prepare("SELECT * FROM bodega");
    $stmt->execute();

    return $stmt->fetchAll();
}

function insertBodega(array $bodega): int{
    $db = getDbConnection();
    $stmt = $db->prepare("INSERT INTO bodega (nombre, direccion, email, telefono, contacto, fundacion, descripcion, restaurante, hotel)
                            VALUES (:nombre, :direccion, :email, :telefono, :contacto, :fundacion, :descripcion, :restaurante, :hotel)");
    $stmt->execute($bodega);

    return (int)$db->lastInsertId();

}

function getBodegaById(int $id): object|false{
    $db = getDbConnection();
    $stmt = $db->prepare("SELECT * FROM bodega WHERE id = :id");
    $data = ["id" => $id];
    $stmt->execute($data);
    return $stmt->fetch();
}

function updateBodega(array $bodega): void{
    $db = getDbConnection();
    $stmt = $db->prepare("UPDATE bodega 
                            SET nombre = :nombre, direccion = :direccion, email = :email, telefono = :telefono,
                                contacto = :contacto, fundacion = :fundacion, descripcion = :descripcion,
                                restaurante = :restaurante, hotel = :hotel
                            WHERE id = :id");

    $stmt->execute($bodega);
}


/**vino */
function getVinoById(int $bodegaId): array{
    $db = getDbConnection();
    $stmt = $db->prepare("SELECT * FROM vino WHERE bodega_id= :bodega_id");
    $data = ["bodega_id" => $bodegaId];
    $stmt->execute($data);

    return $stmt->fetchAll();

}





























