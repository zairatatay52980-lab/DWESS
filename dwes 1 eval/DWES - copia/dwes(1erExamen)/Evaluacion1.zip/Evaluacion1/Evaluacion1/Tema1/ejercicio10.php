<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ejercicio 10</title>
</head>
<body>
    <?php 

   function concatenarTexto($a , $b) {
    return $a . $b ;
   }

   echo concatenarTexto("Hola " , "Mundo");


    ?>
</body>
</html>