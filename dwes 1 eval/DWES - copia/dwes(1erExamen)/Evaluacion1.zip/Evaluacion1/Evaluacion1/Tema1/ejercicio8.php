<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ejercicio 8</title>
</head>
<body>
    <?php

        $numero = $_GET["numero"];

        function cuadrado($numero){
            return $numero * $numero;
        }

        echo "Este numero $numero al cuadrado es: " . cuadrado($numero);

    ?>
</body>
</html>