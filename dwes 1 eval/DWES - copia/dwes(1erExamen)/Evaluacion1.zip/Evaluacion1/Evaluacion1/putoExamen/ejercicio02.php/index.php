<?php 
session_start(); // 1. SIEMPRE EN LA PRIMERA LÍNEA

if (isset($_GET['idioma'])) {
    $idioma = $_GET['idioma'];
    // Guardamos la cookie por 30 días (time() + 3600 * 24 * 30)
    setcookie('idioma', $idioma, time() + (3600 * 24 * 30));
} else {
    // Si no nos pasan idioma por la URL, leemos la cookie guardada (o 'es' por defecto)
    $idioma = $_COOKIE['idioma'] ?? 'es';
}

// Definimos el saludo según el idioma
$saludo = ($idioma === 'eu') ? 'Ongi etorri' : 'Bienvenido';

require "db_functions.php";

$accion = $_GET["accion"] ?? $_GET["accion"] ?? null;

// --- PROCESAR INICIO DE SESIÓN ---
if ($accion === 'hacerLogin') {
    $usuario = $_GET["usuario"] ?? '';
    $password = $_GET["password"] ?? '';

    // Comprobación simple de usuario y contraseña (puedes cambiar 'admin' y '1234')
    if ($usuario === 'admin' && $password === '1234') {
        $_SESSION['usuario'] = $usuario; // Guardamos al usuario en la sesión
        header("Location: index.php");
        exit;
    } else {
        $error = "Usuario o contraseña incorrectos";
        require "views/login.view.php";
        exit;
    }
}

// --- PROCESAR CERRAR SESIÓN ---
if ($accion === 'logout') {
    session_destroy(); // Borra toda la sesión
    header("Location: index.php");
    exit;
}

// --- BARRERA DE SEGURIDAD (PROTECCIÓN) ---
// Si NO hay sesión iniciada, cargamos el Login y bloqueamos el resto del archivo
if (!isset($_SESSION['usuario'])) {
    require "views/login.view.php";
    exit;
}

if(isset($_GET["accion"])){
    $accion = $_GET["accion"];

    switch($accion){
        case 'empleadoDetalles':
            $id = $_GET["id"];
            $empleado = getEmpleadoById($id);

            require "views/detalles.view.php";

            break;

        case 'empleadoEliminar':
            $id = $_GET["id"];
            if($id){
                eliminarEmpleado((int) $id);
            }
            header("Location: index.php");
            exit;

        case 'insertarEmpleado':
            $empleado = array(
                "nombre" => $_GET["nombre"],
                "apellidos" => $_GET["apellidos"],
                "email" => $_GET["email"],
                "dni" => $_GET["dni"],
                "edad" => intval($_GET["edad"]),
                "fecha_nacimiento" => $_GET["fecha_nacimiento"],
                "curriculum" => $_GET["curriculum"],
                "sexo" => $_GET["sexo"]
            );
            insertarEmpleado($empleado);
            cargarIndex();

            break;
            
        case 'empleadoEditar':
            $id = $_GET["id"] ?? null;
            $empleado = getEmpleadoById($id);

            if (!$empleado) {
                header("Location: index.php");
                exit;
            }

            require "views/modificar.view.php";
            break;

        case 'modificarEmpleado':
            $empleado = array(
                "id"               => $_GET["id"] ?? null,
                "nombre"           => $_GET["nombre"] ?? '',
                "apellidos"        => $_GET["apellidos"] ?? '',
                "email"            => $_GET["email"] ?? '',
                "dni"              => $_GET["dni"] ?? '',
                "edad"             => intval($_GET["edad"] ?? 0),
                "fecha_nacimiento" => $_GET["fecha_nacimiento"] ?? null,
                "curriculum"       => $_GET["curriculum"] ?? '',
                "sexo"             => $_GET["sexo"] ?? ''
            );
            
            modificarEmpleado($empleado);
            header("Location: index.php");
            exit;
        case 'buscarEmpleado':
            $busqueda = $_GET["busqueda"] ?? '';
            $empleados = buscarEmpleados($busqueda);
            require "views/index.view.php";
            break;
    }
}else{
    cargarIndex();
}

function cargarIndex(){
    global $saludo;
    $empleados = getAll();

    require "views/index.view.php";

}

?>