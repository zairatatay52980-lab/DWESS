<?php require('layout/head.php'); ?>

<div style="background-color: #f0f0f0; padding: 10px; margin-bottom: 15px;">
    <strong><?= $saludo ?></strong>, <?= htmlspecialchars($_SESSION['usuario']) ?> | 
    
    <!-- Enlaces para cambiar la cookie de idioma -->
    Idioma: 
    <a href="index.php?idioma=es">ES</a> | 
    <a href="index.php?idioma=eu">EU</a> | 

    <a href="index.php?accion=logout">Cerrar sesión</a>
</div>

<form action="index.php" method="get">
    <input type="hidden" name="accion" value="buscarEmpleado">
    <input type="text" name="busqueda" placeholder="Buscar por nombre" value="<?= htmlspecialchars($_GET['busqueda'] ?? '') ?>">
    <input type="submit" value="Buscar">
    
    <?php if (isset($_GET['accion']) && $_GET['accion'] === 'buscarEmpleado'): ?>
        <a href="index.php">Limpiar filtro</a>
    <?php endif; ?>
</form>



<table border=1>

    <thead>
        <th>dni</th><th>nombre</th><th>apellidos</th><th>opciones</th>
    </thead>

    <tbody>

    <?php foreach($empleados as $emple): ?>

    <tr>
        
        <td><?= $emple->dni?></td>
        <td><?= $emple->nombre?></td>
        <td><?= $emple->apellidos ?></td>
        <td><a href="index.php?accion=empleadoDetalles&id=<?=$emple->id ?>">detalles</a>
            <a href="index.php?accion=empleadoEliminar&id=<?=$emple->id ?>">eliminar</a>
            <a href="index.php?accion=empleadoEditar&id=<?= $emple->id ?>">Editar</a>

        </td>
    </tr>
      <?php endforeach; ?>

    <a href="index.php?accion=vaciarLista">Vaciar Lista</a>
    
    

</tbody>
</table>

<h5>Añadir nuevo empleado</h5>
<form action="index.php" method="get">
    <input type="text" name="nombre" placeholder="Nombre" required>
    <input type="text" name="apellidos" placeholder="Apellidos" required>
    <input type="number" name="edad" placeholder="Edad">
    <input type="date" name="fecha_nacimiento" value="2000-01-01">
    <input type="email" name="email" placeholder="Email">
    <input type="text" name="dni" placeholder="DNI" required>
    <select name="sexo">
        <option value="Hombre">Hombre</option>
        <option value="Mujer" selected>Mujer</option>
        <option value="Otro">Otro</option>
    </select>
    <textarea name="curriculum" placeholder="Curriculum"></textarea>

    <input type="submit" value="Insertar">
    <input type="hidden" name="accion" value="insertarEmpleado">
</form>


<?php require('layout/footer.php'); ?>