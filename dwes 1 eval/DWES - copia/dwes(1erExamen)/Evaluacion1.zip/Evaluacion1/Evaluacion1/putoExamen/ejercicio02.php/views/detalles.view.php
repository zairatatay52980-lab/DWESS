<?php require('layout/head.php') ?>

    <table class="table">
        <tr>
            <td class="w-25">DNI</td><td><?= htmlspecialchars($empleado->dni) ?></td>
        </tr>
        <tr>
            <td>Nombre</td><td><?= htmlspecialchars($empleado->nombre) ?></td>
        </tr>
        <tr>
            <td>Apellidos</td><td><?= htmlspecialchars($empleado->apellidos) ?></td>
        </tr>
        <tr>
            <td>Edad</td><td><?= htmlspecialchars($empleado->edad) ?></td>
        </tr>
        <tr>
            <td>Sexo</td><td><?= htmlspecialchars($empleado->sexo) ?></td>
        </tr>
        <tr>
            <td>Fecha de nacimiento</td><td><?= htmlspecialchars($empleado->fecha_nacimiento) ?></td>
        </tr>
        <tr>
            <td>Curriculum</td><td><?= htmlspecialchars($empleado->curriculum) ?></td>
        </tr>
    </table>
<br>
<a href="index.php">Volver</a>

<?php require('layout/footer.php') ?>