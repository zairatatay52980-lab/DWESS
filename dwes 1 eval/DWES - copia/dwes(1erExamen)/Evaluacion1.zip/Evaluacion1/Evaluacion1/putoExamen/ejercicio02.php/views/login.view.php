<?php require('layout/head.php'); ?>

<h2>Iniciar Sesión</h2>

<?php if (isset($error)): ?>
    <p style="color: red; font-weight: bold;"><?= $error ?></p>
<?php endif; ?>

<form action="index.php" method="get">
    <input type="hidden" name="accion" value="hacerLogin">

    <label>Usuario:</label><br>
    <input type="text" name="usuario" placeholder="admin" required><br><br>

    <label>Contraseña:</label><br>
    <input type="password" name="password" placeholder="1234" required><br><br>

    <input type="submit" value="Entrar">
</form>

<?php require('layout/footer.php'); ?>