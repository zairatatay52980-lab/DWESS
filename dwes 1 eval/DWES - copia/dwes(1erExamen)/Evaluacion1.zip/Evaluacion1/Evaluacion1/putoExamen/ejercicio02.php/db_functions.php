<?php

require "database.php";


function getAll(){
    $db = getDbConnection();
    $stmt = $db->prepare("SELECT * FROM empleado");
    $stmt->execute();
    $stmt->setFetchMode(PDO::FETCH_OBJ);
    return $stmt->fetchAll();
}

function busqueda($busqueda = null){
    $db = getDbConnection();
    $stmt = $db->prepare("SELECT * FROM empleado 
                          WHERE nombre LIKE :busqueda");
    $stmt->execute(["busqueda" => "%" . $busqueda ."%"]);
    $stmt->setFetchMode(PDO::FETCH_OBJ);
    return $stmt->fetchAll();
}


function getEmpleadoById($id){
    $db = getDbConnection();
    $stmt = $db->prepare("SELECT * FROM empleado WHERE id=:id");
    $stmt->setFetchMode(PDO::FETCH_OBJ);
    $data = ["id" => $id];
    $stmt->execute($data);
    return $stmt->fetchObject();

}

function eliminarEmpleado(int $id){
    $db = getDbConnection();
    $stmt = $db->prepare("DELETE FROM empleado WHERE id=:id");
    $data = ["id" => $id];
    $stmt->execute($data);

}

function insertarEmpleado(array $empleado){
    $db = getDbConnection();
    $stmt = $db->prepare("INSERT INTO empleado (nombre, apellidos, email, dni, sexo, edad, fecha_nacimiento, curriculum)
                            VALUES (:nombre, :apellidos, :email, :dni, :sexo, :edad, :fecha_nacimiento, :curriculum)");
    $stmt->execute($empleado);
}

function modificarEmpleado(array $empleado){
    $db = getDbConnection();
    $stmt = $db->prepare("UPDATE empleado 
                        SET nombre = :nombre,
                            apellidos = :apellidos,
                            email = :email,
                            dni = :dni,
                            sexo = :sexo,
                            edad = :edad,
                            fecha_nacimiento = :fecha_nacimiento,
                            curriculum = :curriculum
                        WHERE id = :id");
    $stmt->execute($empleado);
}








