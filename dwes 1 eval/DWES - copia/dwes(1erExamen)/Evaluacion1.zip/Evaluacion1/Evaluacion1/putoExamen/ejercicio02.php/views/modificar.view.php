<?php require('layout/head.php'); ?>

<h5>Modificar empleado</h5>

<form action="index.php?accion=modificarEmpleado" method="get">
    <input type="hidden" name="id" value="<?= $empleado->id ?>">

    <input type="text" name="nombre" value="<?= htmlspecialchars($empleado->nombre) ?>" required>
    <input type="text" name="apellidos" value="<?= htmlspecialchars($empleado->apellidos) ?>" required>
    <input type="number" name="edad" value="<?= htmlspecialchars($empleado->edad) ?>">
    <input type="date" name="fecha_nacimiento" value="<?= htmlspecialchars($empleado->fecha_nacimiento) ?>">
    <input type="email" name="email" value="<?= htmlspecialchars($empleado->email) ?>">
    <input type="text" name="dni" value="<?= htmlspecialchars($empleado->dni) ?>" required>
    
    <select name="sexo">
        <option value="Hombre" <?= $empleado->sexo == 'Hombre' ? 'selected' : '' ?>>Hombre</option>
        <option value="Mujer" <?= $empleado->sexo == 'Mujer' ? 'selected' : '' ?>>Mujer</option>
        <option value="Otro" <?= $empleado->sexo == 'Otro' ? 'selected' : '' ?>>Otro</option>
    </select>
    
    <textarea name="curriculum"><?= htmlspecialchars($empleado->curriculum) ?></textarea>

    <input type="submit" value="Guardar Cambios">
    <input type="hidden">
    <input type="hidden" name="id" value="<?= $empleado->id ?>">
    <a href="index.php">Cancelar</a>
</form>

<?php require('layout/footer.php'); ?>