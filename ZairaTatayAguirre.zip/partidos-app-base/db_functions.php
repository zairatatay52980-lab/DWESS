<?php

require 'database.php';


function getAll(){
    $db = getDbConnection();
    $query=$db->prepare("SELECT * FROM partidos");
    $query->execute();
    return $query->fetchAll(PDO::FETCH_OBJ);
}

function insertPartido($data){
    $db = getDbConnection();
    $query=$db->prepare("INSERT INTO partidos(equipo_local, equipo_visitante, liga, localizacion, fecha, publico_asistente, estado)
                            VALUES (:equipo_local, :equipo_visitante, :liga, :localizacion, :fecha, :publico_asistente, :estado)");
    $query -> execute($data);
}

function detallesPartido($id){
    $db = getDbConnection();
    $query=$db->prepare("SELECT equipo_local, equipo_visitante, liga, estado, localizacion, fecha, publico_asistente  FROM partidos WHERE id = :id");
    $query->execute(["id"=>$id]);
    return $query->fetch(PDO::FETCH_OBJ);
}

function detallesAnotaciones($id){
    $db = getDbConnection();
    $query=$db->prepare("SELECT jugador, puntos, equipo FROM anotaciones WHERE partido_id = :id");
    $query->execute(["id"=>$id]);
    return $query->fetchAll(PDO::FETCH_OBJ);
}

function deletePartido($id){
    $db = getDbConnection();
    $query=$db->prepare("DELETE FROM partidos WHERE id = :id");
    $query->execute(["id"=>$id]);
}

function updatePartido($data){
    $db = getDbConnection();
    $query=$db->prepare("UPDATE partidos SET estado =:estado WHERE id=:id");
    $query->execute($data);
}


