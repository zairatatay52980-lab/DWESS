<?php
require 'db_functions.php';

//funcion redirect
function redirect($url){
    header("Location: $url");
    exit;
}

//funcion recoger from post
function recogerFromPost(){
    return[
        "equipo_local" => $_POST["equipo_local"],
        "equipo_visitante" => $_POST["equipo_visitante"],
        "liga" => $_POST["liga"],
        "localizacion" => $_POST["localizacion"],
        "fecha" => $_POST["fecha"],
        "publico_asistente" => $_POST["publico_asistente"],
        "estado" => "Planificado", 
    ];
}


$accion = $_REQUEST["accion"] ?? null;



//switch
if($accion !== null){
    switch($accion){
        case "nuevoPartido":
            require 'views/nuevoPartido.view.php';
            exit;

        case "guardarPartido":
            insertPartido(recogerFromPost());
            redirect('index.php');
            break;

        case "detallesPartido":
            $partido = detallesPartido($_GET["id"]);
            $anotaciones = detallesAnotaciones($_GET["id"]);
            require 'views/detallePartido.view.php';
            exit;

        case "eliminarPartido":
            $id = $_GET["id"];
            deletePartido($id);
            redirect('index.php');
            break;

        case "finalizarPartido":
            $id = $_GET["id"];
            updatePartido(["id"=>$id, "estado"=>"Finalizado"]);
            redirect('index.php');
            break;

        case "cambiarIdioma" :
            setcookie("idioma", $_COOKIE["idioma"]);
            redirect('index.php');
            break;
        
    }
}







$partidos=getAll();
require 'views/index.view.php';



