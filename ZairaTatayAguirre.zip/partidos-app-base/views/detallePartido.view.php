<?php 
    require 'layout/header.php';
?>

<h2>Detalles del partido</h2>

<table border=1>
    <tr>
        <td>Equipo local del partido</td>
        <td>
            <?=$partido->equipo_local?>
        </td>
    </tr>
    <tr>
        <td>Equipo visitante del partido</td>
        <td>
            <?=$partido->equipo_visitante?>
        </td>
    </tr>
    <tr>
        <td>Liga</td>
        <td>
            <?=$partido->liga?>
        </td>
    </tr>
    <tr>
        <td>Estado</td>
        <td>
            <?=$partido->estado?>
        </td>
    </tr>
    <tr>
        <td>Localizacion</td>
        <td>
            <?=$partido->localizacion?>
        </td>
    </tr>
    <tr>
        <td>Fecha</td>
        <td>
            <?=$partido->fecha?>
        </td>
    </tr>
    <tr>
        <td>Publico asistente</td>
        <td>
            <?=$partido->publico_asistente?>
        </td>
    </tr>   
</table>


<h3>Anotaciones del evento </h3>

<?php if(count($anotaciones)===0) :?>
    <p>No hay anotaciones</p>

<?php else:?>

    <table border=1>
        
        <tr>
            <th>Jugadores</th>
            <th>Puntos</th>
            <th>Equipo</th>
        </tr>

        <?php foreach($anotaciones as $anotacion) : ?>
            <tr>
                <td>
                    <?=$anotacion->jugador?>
                </td>
                <td>
                    <?=$anotacion->puntos?>
                </td>   
                <td>
                    <?=$anotacion->equipo?>
                </td>
            </tr>
         <?php endforeach; ?>
    </table>
<?php endif;?>




<br>
    <a href="index.php">Volver a inicio</a>

<?php 
    require 'layout/footer.php';
?>