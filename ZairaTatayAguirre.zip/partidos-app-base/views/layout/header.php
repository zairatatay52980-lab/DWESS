<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Partidos</title>
</head>
<body>

<?php if($_COOKIE === "Eus") : ?>
    <h1>PARTIDUAK</h1>
    <?php else: ?>
        <h1>PARTIDOS</h1>
<?php endif; ?>





