
<br>
<form action="index.php?accion=cambiarIdioma" method="POST">

    <select name="idioma">
        <option value="Es">Es</option>
        <option value="Eus">Eus</option>
    </select>

    <input type="hidden" name="accion" value="cambiarIdioma">
    <input type="submit" value="Cambiar idioma">

</form>