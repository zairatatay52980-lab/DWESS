<?php 
    require 'layout/header.php';
    
?>
    

    <h2>Listado de partidos</h2>


    <a href="index.php?accion=nuevoPartido">Nuevo partido</a>

    <table border=1>
        <tr>
            <th>Equipo local</th>
            <th>Equipo visitante</th>
            <th>Liga</th>
            <th>Estado</th>
            <th>Opciones</th>
        </tr>
        <?php foreach ($partidos as $partido) : ?>
            <tr>
                <td><?=$partido->equipo_local?></td>
                <td><?=$partido->equipo_visitante?></td>
                <td><?=$partido->liga?></td>
                <td><?=$partido->estado?></td>
                <td>
                    <a href="index.php?accion=detallesPartido&id=<?=$partido->id?>">Ver detalles</a>
                    <a href="index.php?accion=finalizarPartido&id=<?=$partido->id?>">Finalizar partido</a>
                    <a href="index.php?accion=eliminarPartido&id=<?=$partido->id?>">Eliminar</a>
                </td>
            </tr>
        <?php endforeach; ?>

    </table>



<?php 
require 'layout/idioma.php';
    require 'layout/footer.php';
?>