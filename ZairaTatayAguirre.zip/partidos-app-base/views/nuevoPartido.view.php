<?php 
    require 'layout/header.php';
?>

<h2>Nuevo Partido</h2>

<form action="index.php?accion=guardarPartido" method="POST">

    <table border=1>

        <tr>
            <td>Equipo local del partido</td>
            <td>
                <input type="text" name="equipo_local">
            </td>
        </tr>
        <tr>
            <td>Equipo visitante del partido</td>
            <td>
                <input type="text" name="equipo_visitante">
            </td>
        </tr>
        <tr>
            <td>Liga</td>
            <td>
                <input type="text" name="liga">
            </td>
        </tr>
        <tr>
            <td>Localizacion</td>
            <td>
                <input type="text" name="localizacion">
            </td>
        </tr>
        <tr>
            <td>Fecha</td>
            <td>
                <input type="date" name="fecha">
            </td>
        </tr>
        <tr>
            <td>Publico asistente</td>
            <td>
                <input type="number" name="publico_asistente">
            </td>
        </tr>

        


        
    </table>

    <br>

    <input type="hidden" name="accion" value="guardarPartido">
    <input type="submit" value="Crear partido">
</form>

<br>

    <a href="index.php">Volver a inicio</a>

<?php 
    require 'layout/footer.php';
?>